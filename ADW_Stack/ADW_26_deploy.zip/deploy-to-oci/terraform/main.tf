# ─────────────────────────────────────────────────────────────────────────────
# UrbanDive · Oracle ADB 23ai (Always Free) · main.tf
# ─────────────────────────────────────────────────────────────────────────────

terraform {
  required_version = ">= 1.3.0"
  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 5.0.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.4.0"
    }
  }
}

# ── Provider ──────────────────────────────────────────────────────────────────
# When run via OCI Resource Manager the provider is auto-configured.
# For local runs, set TF_VAR_* environment variables or use a .tfvars file.
provider "oci" {
  tenancy_ocid     = var.tenancy_ocid
  user_ocid        = var.user_ocid != "" ? var.user_ocid : null
  fingerprint      = var.fingerprint != "" ? var.fingerprint : null
  private_key_path = var.private_key_path != "" ? var.private_key_path : null
  region           = var.region
}

# ── Local computations ─────────────────────────────────────────────────────────
locals {
  # Parse optional IP whitelist into a list
  whitelisted_ips_list = var.whitelisted_ips != "" ? split(",", replace(var.whitelisted_ips, " ", "")) : []

  # Derive a workload label for display
  workload_label = var.db_workload == "DW" ? "ADW" : "ATP"

  # Tags applied to all resources
  defined_tags  = {}
  freeform_tags = {
    "project"     = "UrbanDive"
    "environment" = "hackathon"
    "db_version"  = var.db_version
    "workload"    = local.workload_label
    "managed_by"  = "terraform"
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# AUTONOMOUS DATABASE — Always Free (1 OCPU, 20 GB storage)
# ─────────────────────────────────────────────────────────────────────────────
resource "oci_database_autonomous_database" "urbandive" {
  compartment_id  = var.compartment_ocid
  db_name         = upper(var.db_name)
  display_name    = var.db_display_name
  db_workload     = var.db_workload

  # ── Always Free tier settings ─────────────────────────────────────────────
  is_free_tier              = true
  cpu_core_count            = 1
  compute_model             = "ECPU"
  compute_count             = 2      # 2 ECPUs = Always Free allocation
  data_storage_size_in_gbs  = 20     # Always Free max = 20 GB
  is_auto_scaling_enabled   = false  # Not available on free tier
  is_auto_scaling_for_storage_enabled = false

  # ── Oracle 23ai ───────────────────────────────────────────────────────────
  db_version      = var.db_version   # "23ai" enables AI Vector Search, Property Graph, JSON Duality

  # ── Security ──────────────────────────────────────────────────────────────
  admin_password              = var.admin_password
  is_mtls_connection_required = var.is_mtls_required
  license_model               = "LICENSE_INCLUDED"

  # Character sets — UTF-8 is required for UrbanDive data (supports all languages)
  character_set   = "AL32UTF8"
  ncharacter_set  = "AL16UTF16"

  # ── Optional IP allow-list ────────────────────────────────────────────────
  dynamic "whitelisted_ips" {
    for_each = length(local.whitelisted_ips_list) > 0 ? [1] : []
    content {
      # whitelisted_ips is an attribute, not a block — set inline below
    }
  }

  whitelisted_ips = length(local.whitelisted_ips_list) > 0 ? local.whitelisted_ips_list : null

  # ── Tags ──────────────────────────────────────────────────────────────────
  freeform_tags = local.freeform_tags
  defined_tags  = local.defined_tags

  # ── Lifecycle ─────────────────────────────────────────────────────────────
  # Prevent accidental deletion of the database; remove this block to allow destroy
  lifecycle {
    prevent_destroy = false   # Set to true in production!
    ignore_changes  = [
      # Ignore password changes after initial creation (manage via OCI Console)
      admin_password,
    ]
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# WALLET — generate a pre-authenticated download URL for the wallet
# Note: The wallet itself cannot be stored in Terraform state (it's a binary zip).
# The output below gives the OCI CLI command to download it.
# ─────────────────────────────────────────────────────────────────────────────

# Data source to read back the created database (refreshes connection strings)
data "oci_database_autonomous_database" "urbandive" {
  autonomous_database_id = oci_database_autonomous_database.urbandive.id
}
