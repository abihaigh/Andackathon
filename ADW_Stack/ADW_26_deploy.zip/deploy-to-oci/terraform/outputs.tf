# ─────────────────────────────────────────────────────────────────────────────
# UrbanDive · Oracle ADB 23ai (Always Free) · outputs.tf
# ─────────────────────────────────────────────────────────────────────────────

output "adb_ocid" {
  description = "OCID of the provisioned Autonomous Database."
  value       = oci_database_autonomous_database.urbandive.id
}

output "adb_state" {
  description = "Lifecycle state of the database (AVAILABLE = ready)."
  value       = oci_database_autonomous_database.urbandive.lifecycle_state
}

output "adb_connection_strings" {
  description = "All available connection strings (high / medium / low / tp / tpurgent)."
  value       = data.oci_database_autonomous_database.urbandive.connection_strings
}

output "adb_service_console_url" {
  description = "Direct link to the Autonomous Database console in OCI."
  value       = data.oci_database_autonomous_database.urbandive.service_console_url
}

output "adb_db_name" {
  description = "The DB_NAME used internally."
  value       = oci_database_autonomous_database.urbandive.db_name
}

output "adb_db_version" {
  description = "Oracle Database version deployed."
  value       = oci_database_autonomous_database.urbandive.db_version
}

output "adb_workload" {
  description = "Workload type: DW (ADW) or OLTP (ATP)."
  value       = oci_database_autonomous_database.urbandive.db_workload
}

output "adb_is_free_tier" {
  description = "Confirms this is an Always Free database."
  value       = oci_database_autonomous_database.urbandive.is_free_tier
}

output "wallet_download_command" {
  description = "OCI CLI command to download the connection wallet. Run this locally after provisioning."
  value = join(" ", [
    "oci db autonomous-database generate-wallet",
    "--autonomous-database-id", oci_database_autonomous_database.urbandive.id,
    "--password 'YOUR_WALLET_PASSWORD'",
    "--file wallet_${lower(oci_database_autonomous_database.urbandive.db_name)}.zip",
    "--region", var.region
  ])
}

output "sqlcl_connect_command" {
  description = "SQLcl connection command (replace YOUR_PASSWORD with your ADMIN password)."
  value = "sql admin/YOUR_ADMIN_PASSWORD@${lower(oci_database_autonomous_database.urbandive.db_name)}_high"
}

output "next_steps" {
  description = "What to do after provisioning."
  value = <<-EOT
    ╔══════════════════════════════════════════════════════════════════════╗
    ║  UrbanDive · Oracle ADB 23ai provisioned successfully!             ║
    ╠══════════════════════════════════════════════════════════════════════╣
    ║  1. Download wallet:  use the 'wallet_download_command' output      ║
    ║  2. Unzip wallet and set:  export TNS_ADMIN=/path/to/wallet/        ║
    ║  3. Connect:  sql admin/YOUR_PASSWORD@${lower(oci_database_autonomous_database.urbandive.db_name)}_high                ║
    ║  4. Load data:  @00_run_all.sql  (from UrbanDive SQL package)       ║
    ║                                                                      ║
    ║  Console:  ${data.oci_database_autonomous_database.urbandive.service_console_url}
    ╚══════════════════════════════════════════════════════════════════════╝
  EOT
}
