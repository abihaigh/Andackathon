# UrbanDive — Deploy to Oracle Cloud

[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?region=home&zipUrl=https%3A%2F%2Fgithub.com%2FYOUR_GITHUB_USERNAME%2FYOUR_REPO_NAME%2Farchive%2Frefs%2Fheads%2Fmain.zip)

[![Validate Terraform](https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME/actions/workflows/validate-terraform.yml/badge.svg)](https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME/actions/workflows/validate-terraform.yml)

> **One click** to provision an Oracle Autonomous Database 23ai (Always Free) for the UrbanDive urban analytics dataset.

---

## What this deploys

| Resource | Specification |
|---|---|
| **Database type** | Oracle Autonomous Data Warehouse (ADW) |
| **Version** | Oracle 23ai — includes AI Vector Search, Property Graph, JSON Duality Views |
| **Tier** | Always Free (no credit card charges) |
| **Compute** | 2 ECPUs (1 OCPU equivalent) |
| **Storage** | 20 GB |
| **Auto-scaling** | Disabled (free tier) |
| **Character set** | AL32UTF8 (full Unicode) |

---

## Quick start

### 1 — Click the button above

You'll be taken to **OCI Resource Manager** → Create Stack.

### 2 — Log in or create a free OCI account

If you don't have an account: [cloud.oracle.com/free](https://cloud.oracle.com/free) — no credit card required for Always Free resources.

### 3 — Fill in the form

| Field | Guidance |
|---|---|
| **Compartment** | Select your tenancy root or any child compartment |
| **Database Name** | Alphanumeric, max 14 chars (default: `URBANDIVE`) |
| **Workload type** | Leave as `DW` (Data Warehouse) for UrbanDive analytics |
| **ADMIN Password** | Min 12 chars, must include upper, lower, digit, and `#` or `_` |

### 4 — Apply the stack

Click **Next → Next → Apply**. Provisioning takes ~3 minutes.

### 5 — Download your wallet

After the stack apply completes, copy the `wallet_download_command` from the job outputs and run it:

```bash
oci db autonomous-database generate-wallet \
  --autonomous-database-id <your-adb-ocid> \
  --password 'WalletPassword1#' \
  --file wallet_urbandive.zip \
  --region us-ashburn-1
```

### 6 — Connect and load UrbanDive data

```bash
# Unzip the wallet
unzip wallet_urbandive.zip -d wallet/
export TNS_ADMIN=$(pwd)/wallet

# Connect with SQLcl
sql admin/YOUR_ADMIN_PASSWORD@urbandive_high

# Load the UrbanDive dataset (275,000+ rows + 235 documents)
SQL> @00_run_all.sql
```

---

## Repository structure

```
.
├── terraform/
│   ├── main.tf          ← ADB resource definition
│   ├── variables.tf     ← All configurable inputs
│   ├── outputs.tf       ← Connection strings, OCID, next steps
│   └── schema.yaml      ← OCI Resource Manager UI form definition
├── .github/
│   └── workflows/
│       └── validate-terraform.yml  ← Auto-validates on every push
└── README.md            ← You are here
```

---

## Running locally (without the button)

```bash
# Prerequisites: OCI CLI configured, Terraform ≥ 1.3

cd terraform/

# Create a .tfvars file (never commit this — it's in .gitignore)
cat > terraform.tfvars <<EOF
tenancy_ocid     = "ocid1.tenancy.oc1..xxxx"
user_ocid        = "ocid1.user.oc1..xxxx"
fingerprint      = "xx:xx:xx:xx:xx:xx"
private_key_path = "~/.oci/oci_api_key.pem"
region           = "us-ashburn-1"
compartment_ocid = "ocid1.compartment.oc1..xxxx"
admin_password   = "YourSecurePassword1#"
EOF

terraform init
terraform plan
terraform apply
```

---

## After provisioning — key Oracle 23ai features

```sql
-- AI Vector Search
CREATE TABLE embeddings (id NUMBER, vec VECTOR(384, FLOAT32));

-- Property Graph (transit network)
CREATE PROPERTY GRAPH transit_graph
  VERTEX TABLES (TRANSIT_STOPS)
  EDGE TABLES (TRANSIT_STOP_CONNECTIONS
    SOURCE KEY (from_stop_id) REFERENCES TRANSIT_STOPS(stop_id)
    DESTINATION KEY (to_stop_id) REFERENCES TRANSIT_STOPS(stop_id));

-- JSON Duality View
CREATE OR REPLACE JSON RELATIONAL DUALITY VIEW neighborhood_dv AS
  SELECT JSON { 'neighborhood': n.neighborhood,
                'population': n.population_2024 }
  FROM NEIGHBORHOODS n;

-- Oracle Text full-text search on documents
SELECT doc_filename FROM DOCUMENTS
WHERE  CONTAINS(doc_content, 'ambulance AND hospital') > 0;
```

---

## License

MIT — see [LICENSE](LICENSE)
