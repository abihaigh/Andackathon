# ─────────────────────────────────────────────────────────────────────────────
# UrbanDive · Oracle ADB 23ai (Always Free) · variables.tf
# ─────────────────────────────────────────────────────────────────────────────

variable "tenancy_ocid" {
  description = "OCID of the OCI tenancy. Injected automatically by OCI Resource Manager."
  type        = string
}

variable "user_ocid" {
  description = "OCID of the OCI user. Injected automatically by OCI Resource Manager."
  type        = string
  default     = ""
}

variable "fingerprint" {
  description = "API key fingerprint. Injected automatically by OCI Resource Manager."
  type        = string
  default     = ""
}

variable "private_key_path" {
  description = "Path to API private key. Used only in local (non-Resource-Manager) execution."
  type        = string
  default     = ""
}

variable "region" {
  description = "OCI region identifier (e.g. us-ashburn-1). Injected automatically by OCI Resource Manager."
  type        = string
}

variable "compartment_ocid" {
  description = "OCID of the compartment where the ADB will be created."
  type        = string
}

# ── Database ──────────────────────────────────────────────────────────────────

variable "db_name" {
  description = "Short alphanumeric database name (max 14 chars, must start with a letter)."
  type        = string
  default     = "URBANDIVE"

  validation {
    condition     = can(regex("^[A-Za-z][A-Za-z0-9]{0,13}$", var.db_name))
    error_message = "db_name must start with a letter, be alphanumeric only, and be 1–14 characters long."
  }
}

variable "db_display_name" {
  description = "Human-readable display name shown in the OCI Console."
  type        = string
  default     = "UrbanDive ADB 26ai"
}

variable "db_workload" {
  description = "DW = Autonomous Data Warehouse, OLTP = Autonomous Transaction Processing."
  type        = string
  default     = "DW"

  validation {
    condition     = contains(["DW", "OLTP"], var.db_workload)
    error_message = "db_workload must be either 'DW' or 'OLTP'."
  }
}

variable "db_version" {
  description = "Oracle Database version. Use '26ai' for AI Vector Search and Property Graph support."
  type        = string
  default     = "26ai"
}

variable "admin_password" {
  description = "Password for the ADMIN user. Must be 12–30 chars with uppercase, lowercase, digit, and special char (#_)."
  type        = string
  sensitive   = true
}

variable "is_mtls_required" {
  description = "If true, wallet-based mTLS connections are required. Set false to allow TLS-only connections."
  type        = bool
  default     = true
}

variable "whitelisted_ips" {
  description = "Comma-separated list of IPs/CIDRs allowed to connect. Empty = allow all."
  type        = string
  default     = ""
}
