# =============================================================================
# Oracle Autonomous Database 26ai — Always Free Tier
# OCI Resource Manager compatible
# =============================================================================

terraform {
  required_version = ">= 1.2.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 5.0.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.0.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Provider
# Resource Manager injects credentials automatically via instance principal.
# Only 'region' is needed here.
# -----------------------------------------------------------------------------
provider "oci" {
  region = var.region
}

# -----------------------------------------------------------------------------
# Random suffix — keeps db_name unique on re-deploys
# -----------------------------------------------------------------------------
resource "random_string" "suffix" {
  length  = 4
  special = false
  upper   = false
  numeric = true
}

# -----------------------------------------------------------------------------
# Autonomous Database — Always Free, Oracle Database 26ai
# -----------------------------------------------------------------------------
resource "oci_database_autonomous_database" "adb26ai" {

  compartment_id = var.compartment_ocid
  display_name   = var.adb_display_name
  db_name        = "${var.adb_db_name}${random_string.suffix.result}"

  # ---- Always Free ---------------------------------------------------------
  is_free_tier             = true
  cpu_core_count           = 1
  data_storage_size_in_gbs = 20

  # ---- Database version: locked to 26ai ------------------------------------
  db_version  = "26ai"
  db_workload = "OLTP"

  # ---- Licensing -----------------------------------------------------------
  license_model                       = "LICENSE_INCLUDED"
  is_auto_scaling_enabled             = false
  is_auto_scaling_for_storage_enabled = false

  # ---- Admin password (passed via schema.yaml password field) --------------
  admin_password = var.adb_admin_password

  # ---- Network: wallet-free TLS by default ---------------------------------
  is_mtls_connection_required = false

  # ---- Character sets ------------------------------------------------------
  character_set  = "AL32UTF8"
  ncharacter_set = "AL16UTF16"

  # ---- Backup --------------------------------------------------------------
  is_local_data_guard_enabled = false

  # ---- Tags ----------------------------------------------------------------
  freeform_tags = {
    "DeployedBy" = "Terraform"
    "Stack"      = "ADB-26ai-Free"
  }

  timeouts {
    create = "60m"
    update = "60m"
    delete = "30m"
  }
}
