# =============================================================================
# Variables — Oracle Autonomous Database 26ai Free
# =============================================================================

variable "region" {
  description = "OCI region identifier (e.g. uk-london-1, us-ashburn-1)."
  type        = string
  default     = "us-ashburn-1"
}

variable "compartment_ocid" {
  description = "OCID of the compartment in which to create the Autonomous Database."
  type        = string
}

variable "adb_display_name" {
  description = "Display name shown in the OCI Console."
  type        = string
  default     = "ADB26aiFree"
}

variable "adb_db_name" {
  description = "Short alphanumeric database name (max 10 chars — a 4-char suffix is appended)."
  type        = string
  default     = "ADB26AI"

  validation {
    condition     = can(regex("^[A-Za-z][A-Za-z0-9]{0,9}$", var.adb_db_name))
    error_message = "adb_db_name must start with a letter, be alphanumeric only, and be 10 characters or fewer."
  }
}

variable "adb_admin_password" {
  description = <<-EOT
    Password for the ADMIN database user.
    Rules:
      • 12–30 characters
      • At least 1 uppercase letter
      • At least 1 lowercase letter
      • At least 1 digit
      • At least 1 special character: # _ -
      • Must NOT contain the word "admin"
  EOT
  type      = string
  sensitive = true

  validation {
    condition = (
      length(var.adb_admin_password) >= 12 &&
      length(var.adb_admin_password) <= 30 &&
      can(regex("[A-Z]", var.adb_admin_password)) &&
      can(regex("[a-z]", var.adb_admin_password)) &&
      can(regex("[0-9]", var.adb_admin_password)) &&
      can(regex("[#_\\-]", var.adb_admin_password))
    )
    error_message = "Password must be 12-30 chars and include uppercase, lowercase, a digit, and one of: # _ -"
  }
}
