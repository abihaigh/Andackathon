# =============================================================================
# Outputs
# =============================================================================

output "adb_id" {
  description = "OCID of the provisioned Autonomous Database."
  value       = oci_database_autonomous_database.adb26ai.id
}

output "adb_display_name" {
  description = "Display name of the Autonomous Database."
  value       = oci_database_autonomous_database.adb26ai.display_name
}

output "adb_db_name" {
  description = "Short database name used in connection strings."
  value       = oci_database_autonomous_database.adb26ai.db_name
}

output "adb_db_version" {
  description = "Oracle Database version running on this ADB."
  value       = oci_database_autonomous_database.adb26ai.db_version
}

output "adb_state" {
  description = "Lifecycle state of the Autonomous Database."
  value       = oci_database_autonomous_database.adb26ai.state
}

output "adb_service_console_url" {
  description = "Service Console URL (SQL Developer Web, APEX, Graph Studio, ML Studio)."
  value       = oci_database_autonomous_database.adb26ai.service_console_url
}

output "adb_connection_strings" {
  description = "Connection string profiles (HIGH / MEDIUM / LOW / TP / TPURGENT)."
  value       = oci_database_autonomous_database.adb26ai.connection_strings
}

output "connect_hint" {
  description = "How to connect — no wallet required (mTLS is OFF)."
  value       = "Connect via TLS without a wallet. Use the HIGH/MEDIUM/LOW profiles from adb_connection_strings with any OCI-supported client."
}
