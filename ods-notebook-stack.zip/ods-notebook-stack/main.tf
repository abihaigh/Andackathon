# =============================================================================
# OCI Data Science — Project + Notebook Session
# OCI Resource Manager compatible stack
# Includes: VCN, public subnet, internet gateway, DS project, notebook session
# =============================================================================

terraform {
  required_version = ">= 1.2.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 5.0.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.0.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Provider — Resource Manager injects credentials automatically
# -----------------------------------------------------------------------------
provider "oci" {
  region = var.region
}

# -----------------------------------------------------------------------------
# Random suffix for unique naming
# -----------------------------------------------------------------------------
resource "random_string" "suffix" {
  length  = 4
  special = false
  upper   = false
  numeric = true
}

locals {
  name_suffix = random_string.suffix.result
}

# =============================================================================
# NETWORKING — simple public VCN (required for notebook session egress)
# =============================================================================

resource "oci_core_vcn" "ds_vcn" {
  compartment_id = var.compartment_ocid
  display_name   = "ds-vcn-${local.name_suffix}"
  cidr_blocks    = ["10.0.0.0/16"]
  dns_label      = "dsvcn${local.name_suffix}"

  freeform_tags = {
    "Stack" = "OCI-DataScience-Notebook"
  }
}

resource "oci_core_internet_gateway" "ds_igw" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.ds_vcn.id
  display_name   = "ds-igw-${local.name_suffix}"
  enabled        = true
}

resource "oci_core_route_table" "ds_route_table" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.ds_vcn.id
  display_name   = "ds-route-table-${local.name_suffix}"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.ds_igw.id
  }
}

resource "oci_core_security_list" "ds_security_list" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.ds_vcn.id
  display_name   = "ds-security-list-${local.name_suffix}"

  # Allow all egress (needed for pip installs, OCI services, etc.)
  egress_security_rules {
    destination = "0.0.0.0/0"
    protocol    = "all"
    stateless   = false
  }

  # Allow HTTPS inbound (notebook UI over port 443)
  ingress_security_rules {
    protocol  = "6" # TCP
    source    = "0.0.0.0/0"
    stateless = false

    tcp_options {
      min = 443
      max = 443
    }
  }

  # Allow SSH inbound (optional — for terminal access)
  ingress_security_rules {
    protocol  = "6"
    source    = "0.0.0.0/0"
    stateless = false

    tcp_options {
      min = 22
      max = 22
    }
  }
}

resource "oci_core_subnet" "ds_subnet" {
  compartment_id    = var.compartment_ocid
  vcn_id            = oci_core_vcn.ds_vcn.id
  display_name      = "ds-subnet-${local.name_suffix}"
  cidr_block        = "10.0.0.0/24"
  dns_label         = "dssub${local.name_suffix}"
  route_table_id    = oci_core_route_table.ds_route_table.id
  security_list_ids = [oci_core_security_list.ds_security_list.id]

  # Public subnet — notebook session gets a public IP for console access
  prohibit_public_ip_on_vnic = false
}

# =============================================================================
# OCI DATA SCIENCE — Project
# =============================================================================

resource "oci_datascience_project" "ds_project" {
  compartment_id = var.compartment_ocid
  display_name   = "${var.project_display_name}-${local.name_suffix}"
  description    = var.project_description

  freeform_tags = {
    "Stack"       = "OCI-DataScience-Notebook"
    "DeployedBy"  = "Terraform"
  }
}

# =============================================================================
# OCI DATA SCIENCE — Notebook Session
# =============================================================================

resource "oci_datascience_notebook_session" "notebook" {
  compartment_id = var.compartment_ocid
  project_id     = oci_datascience_project.ds_project.id
  display_name   = "${var.notebook_display_name}-${local.name_suffix}"

  notebook_session_config_details {
    shape = var.notebook_shape

    # Flex shape config — ignored for non-flex shapes
    notebook_session_shape_config_details {
      ocpus         = var.notebook_ocpus
      memory_in_gbs = var.notebook_memory_in_gbs
    }

    subnet_id              = oci_core_subnet.ds_subnet.id
    block_storage_size_in_gbs = var.block_storage_size_in_gbs
  }

  freeform_tags = {
    "Stack"      = "OCI-DataScience-Notebook"
    "DeployedBy" = "Terraform"
  }

  timeouts {
    create = "30m"
    update = "30m"
    delete = "20m"
  }
}
