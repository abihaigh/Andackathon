# =============================================================================
# iam_policies.tf — OPTIONAL
# Pre-requisite IAM policies for OCI Data Science
#
# IMPORTANT: These policies require TENANCY-LEVEL admin permissions to create.
# If you have admin access, uncomment and apply this file.
# If not, ask your tenancy admin to create these policies manually before
# deploying the notebook stack.
#
# Alternatively, use the OCI Console:
# Identity & Security → Policies → Create Policy
# =============================================================================

# Uncomment the locals and resource blocks below if you have admin rights
# and want Terraform to create the policies automatically.

 locals {
   ds_policies = [
     "allow service datascience to use virtual-network-family in tenancy",
     "allow group <your-group> to manage data-science-family in compartment <your-compartment>",
     "allow group <your-group> to use virtual-network-family in compartment <your-compartment>",
     "allow group <your-group> to manage object-family in compartment <your-compartment>",
     "allow group <your-group> to read repos in tenancy",
   ]
 }

 resource "oci_identity_policy" "ds_policies" {
   compartment_id = var.compartment_ocid   # use tenancy OCID for tenancy-level
   name           = "DataSciencePolicies-${random_string.suffix.result}"
   description    = "Policies required for OCI Data Science notebook sessions."
   statements     = local.ds_policies
 }

# =============================================================================
# MINIMUM REQUIRED POLICIES (apply manually if needed)
# Replace <group-name> and <compartment-name> with your values.
# =============================================================================
#
# 1. Service-level (tenancy scope — requires admin):
#    allow service datascience to use virtual-network-family in tenancy
#
# 2. User group (compartment scope):
#    allow group <group-name> to manage data-science-family in compartment <compartment-name>
#    allow group <group-name> to use virtual-network-family in compartment <compartment-name>
#    allow group <group-name> to manage object-family in compartment <compartment-name>
#    allow group <group-name> to read repos in tenancy
#
# Docs: https://docs.oracle.com/en-us/iaas/data-science/using/policies.htm
