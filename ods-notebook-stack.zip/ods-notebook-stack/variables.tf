# =============================================================================
# Variables — OCI Data Science Notebook Session
# =============================================================================

variable "region" {
  description = "OCI region identifier (e.g. uk-london-1, us-ashburn-1)."
  type        = string
  default     = "us-ashburn-1"
}

variable "compartment_ocid" {
  description = "OCID of the compartment in which to create the Data Science resources."
  type        = string
}

# -----------------------------------------------------------------------------
# Project
# -----------------------------------------------------------------------------
variable "project_display_name" {
  description = "Display name for the Data Science Project."
  type        = string
  default     = "DataScienceProject"
}

variable "project_description" {
  description = "Description for the Data Science Project."
  type        = string
  default     = "OCI Data Science project deployed via Terraform."
}

# -----------------------------------------------------------------------------
# Notebook Session
# -----------------------------------------------------------------------------
variable "notebook_display_name" {
  description = "Display name for the Notebook Session."
  type        = string
  default     = "NotebookSession"
}

variable "notebook_shape" {
  description = <<-EOT
    Compute shape for the notebook session.
      VM.Standard.E4.Flex  — AMD EPYC, flexible OCPU/memory (recommended)
      VM.Standard.E3.Flex  — AMD EPYC Gen3, flexible
      VM.Standard3.Flex    — Intel Xeon, flexible
      VM.Standard.A1.Flex  — Arm Ampere A1 (Always Free eligible)
  EOT
  type    = string
  default = "VM.Standard.E4.Flex"

  validation {
    condition = contains([
      "VM.Standard.E4.Flex",
      "VM.Standard.E3.Flex",
      "VM.Standard3.Flex",
      "VM.Standard.A1.Flex"
    ], var.notebook_shape)
    error_message = "notebook_shape must be one of: VM.Standard.E4.Flex, VM.Standard.E3.Flex, VM.Standard3.Flex, VM.Standard.A1.Flex."
  }
}

variable "notebook_ocpus" {
  description = "Number of OCPUs for the notebook session (flex shapes only). Min: 1, recommended: 2–4."
  type        = number
  default     = 2

  validation {
    condition     = var.notebook_ocpus >= 1 && var.notebook_ocpus <= 64
    error_message = "notebook_ocpus must be between 1 and 64."
  }
}

variable "notebook_memory_in_gbs" {
  description = "Memory in GB for the notebook session (flex shapes only). Min: 15 GB per OCPU."
  type        = number
  default     = 32

  validation {
    condition     = var.notebook_memory_in_gbs >= 15 && var.notebook_memory_in_gbs <= 1024
    error_message = "notebook_memory_in_gbs must be between 15 and 1024."
  }
}

variable "block_storage_size_in_gbs" {
  description = "Block storage size in GB attached to the notebook session. Min: 50 GB."
  type        = number
  default     = 100

  validation {
    condition     = var.block_storage_size_in_gbs >= 50 && var.block_storage_size_in_gbs <= 10240
    error_message = "block_storage_size_in_gbs must be between 50 and 10240."
  }
}
