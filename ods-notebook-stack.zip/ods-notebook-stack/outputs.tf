# =============================================================================
# Outputs — OCI Data Science Notebook Session
# =============================================================================

output "ds_project_id" {
  description = "OCID of the Data Science Project."
  value       = oci_datascience_project.ds_project.id
}

output "ds_project_name" {
  description = "Display name of the Data Science Project."
  value       = oci_datascience_project.ds_project.display_name
}

output "notebook_session_id" {
  description = "OCID of the Notebook Session."
  value       = oci_datascience_notebook_session.notebook.id
}

output "notebook_session_url" {
  description = "Direct URL to open the JupyterLab notebook session."
  value       = oci_datascience_notebook_session.notebook.notebook_session_url
}

output "notebook_session_state" {
  description = "Lifecycle state of the Notebook Session."
  value       = oci_datascience_notebook_session.notebook.state
}

output "notebook_shape" {
  description = "Compute shape used by the Notebook Session."
  value       = var.notebook_shape
}

output "notebook_ocpus" {
  description = "Number of OCPUs allocated to the Notebook Session."
  value       = var.notebook_ocpus
}

output "notebook_memory_gb" {
  description = "Memory in GB allocated to the Notebook Session."
  value       = var.notebook_memory_in_gbs
}

output "vcn_id" {
  description = "OCID of the VCN created for this stack."
  value       = oci_core_vcn.ds_vcn.id
}

output "subnet_id" {
  description = "OCID of the subnet used by the Notebook Session."
  value       = oci_core_subnet.ds_subnet.id
}

output "next_steps" {
  description = "What to do after deployment."
  value       = "1. Click notebook_session_url to open JupyterLab. 2. Install packages via pip in a terminal cell. 3. Use ads (Oracle ADS) library for OCI-native ML workflows."
}
